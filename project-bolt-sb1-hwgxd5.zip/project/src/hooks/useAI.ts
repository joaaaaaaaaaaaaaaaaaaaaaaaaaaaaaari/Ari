import { useState } from 'react';
import { useStore } from '../store/useStore';
import { generateResponse } from '../services/gemini';
import { textToSpeech, playAudio } from '../services/elevenlabs';
import { detectLanguage } from '../utils/language';

export function useAI() {
  const [isProcessing, setIsProcessing] = useState(false);
  const { addMessage } = useStore();

  const processMessage = async (content: string) => {
    setIsProcessing(true);
    try {
      // Add user message
      const userMessage = {
        id: Date.now().toString(),
        content,
        role: 'user' as const,
        timestamp: Date.now(),
      };
      addMessage(userMessage);

      // Detect language and generate response
      const [response, language] = await Promise.all([
        generateResponse(content),
        detectLanguage(content)
      ]);

      const aiMessage = {
        id: (Date.now() + 1).toString(),
        content: response,
        role: 'assistant' as const,
        timestamp: Date.now(),
        language,
      };
      addMessage(aiMessage);

      return aiMessage;
    } catch (error) {
      console.error('Error processing message:', error);
      throw error;
    } finally {
      setIsProcessing(false);
    }
  };

  const speakResponse = async (text: string, language: string) => {
    try {
      const audioBuffer = await textToSpeech(text, language);
      await playAudio(audioBuffer);
    } catch (error) {
      console.error('Error in speech synthesis:', error);
      throw error;
    }
  };

  return {
    processMessage,
    speakResponse,
    isProcessing,
  };
}