import { GoogleGenerativeAI } from '@google/generative-ai';
import { API_KEYS } from '../config/constants';

const genAI = new GoogleGenerativeAI(API_KEYS.GEMINI);
const model = genAI.getGenerativeModel({ model: 'gemini-pro' });

export async function generateResponse(prompt: string): Promise<string> {
  try {
    const result = await model.generateContent(prompt);
    const response = await result.response;
    return response.text();
  } catch (error) {
    console.error('Error generating response:', error);
    throw new Error('Failed to generate response');
  }
}