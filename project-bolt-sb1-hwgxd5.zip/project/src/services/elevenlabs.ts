import { API_KEYS } from '../config/constants';

interface VoiceSettings {
  stability: number;
  similarity_boost: number;
  style: number;
  use_speaker_boost: boolean;
  speaking_rate: number;
}

const getOptimizedVoiceSettings = (language: string): VoiceSettings => {
  const baseSettings: VoiceSettings = {
    stability: 0.71,           // Balanced stability for natural sound
    similarity_boost: 0.85,    // Enhanced voice similarity
    style: 0.35,              // Expressive speech parameter
    use_speaker_boost: true,   // Enhanced clarity
    speaking_rate: 1.25,       // Increased to 1.25x speed as requested
  };

  // Language-specific optimizations
  switch (language) {
    case 'ar':
      return {
        ...baseSettings,
        speaking_rate: 1.25,   // Maintain 1.25x speed for Arabic
        stability: 0.75,       // Higher stability for Arabic pronunciation
      };
    case 'zh':
      return {
        ...baseSettings,
        stability: 0.8,        // Higher stability for tonal language
        speaking_rate: 1.25,   // Maintain 1.25x speed for Chinese
      };
    default:
      return baseSettings;
  }
};

export async function textToSpeech(text: string, language: string): Promise<ArrayBuffer> {
  const url = `https://api.elevenlabs.io/v1/text-to-speech/${API_KEYS.ELEVENLABS_VOICE_ID}/stream`;
  const voiceSettings = getOptimizedVoiceSettings(language);
  
  try {
    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'xi-api-key': API_KEYS.ELEVENLABS,
      },
      body: JSON.stringify({
        text,
        model_id: 'eleven_multilingual_v2',
        voice_settings: voiceSettings,
        optimize_streaming_latency: 3, // Maximum optimization for faster response
      }),
    });

    if (!response.ok) {
      throw new Error('Failed to convert text to speech');
    }

    return await response.arrayBuffer();
  } catch (error) {
    console.error('Error in text-to-speech:', error);
    throw error;
  }
}

export async function playAudio(audioBuffer: ArrayBuffer): Promise<void> {
  const audioContext = new (window.AudioContext || window.webkitAudioContext)();
  const audioSource = audioContext.createBufferSource();
  
  try {
    const decodedData = await audioContext.decodeAudioData(audioBuffer);
    
    // Set playback rate to match voice settings
    audioSource.buffer = decodedData;
    audioSource.playbackRate.value = 1.25; // Match the 1.25x speed setting
    
    // Optimized compression for faster speech
    const compressor = audioContext.createDynamicsCompressor();
    compressor.threshold.value = -24;
    compressor.knee.value = 30;
    compressor.ratio.value = 12;
    compressor.attack.value = 0.002; // Faster attack for quicker response
    compressor.release.value = 0.2;  // Shorter release for faster speech
    
    // Connect the audio processing chain
    audioSource.connect(compressor);
    compressor.connect(audioContext.destination);
    
    audioSource.start(0);
  } catch (error) {
    console.error('Error playing audio:', error);
    throw error;
  }
}