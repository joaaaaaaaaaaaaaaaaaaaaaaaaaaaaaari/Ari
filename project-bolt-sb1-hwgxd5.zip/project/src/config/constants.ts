export const API_KEYS = {
  GEMINI: 'AIzaSyBTgxBfnPAnkqCMm8Qcuih4hjHlmS7PEo0',
  ELEVENLABS: 'sk_3141cbf174b707a82f3a974afd78378d60c58370cda5130b',
  ELEVENLABS_VOICE_ID: '9BWtsMINqrJLrRacOk9x'
} as const;