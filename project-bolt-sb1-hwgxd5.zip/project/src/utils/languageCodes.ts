export const languageCodes: { [key: string]: string } = {
  'ara': 'ar', // Arabic
  'eng': 'en', // English
  'fra': 'fr', // French
  'deu': 'de', // German
  'hin': 'hi', // Hindi
  'ita': 'it', // Italian
  'jpn': 'ja', // Japanese
  'kor': 'ko', // Korean
  'por': 'pt', // Portuguese
  'rus': 'ru', // Russian
  'spa': 'es', // Spanish
  'tur': 'tr', // Turkish
  'zho': 'zh', // Chinese
  // Add more languages as needed
};