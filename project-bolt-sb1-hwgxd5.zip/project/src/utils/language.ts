// Simple language detection based on character sets and common patterns
export async function detectLanguage(text: string): Promise<string> {
  // Arabic characters
  if (/[\u0600-\u06FF]/.test(text)) {
    return 'ar';
  }

  // Chinese characters
  if (/[\u4E00-\u9FFF]/.test(text)) {
    return 'zh';
  }

  // Japanese characters (Hiragana, Katakana, Kanji)
  if (/[\u3040-\u30FF\u4E00-\u9FAF]/.test(text)) {
    return 'ja';
  }

  // Korean characters
  if (/[\uAC00-\uD7AF\u1100-\u11FF]/.test(text)) {
    return 'ko';
  }

  // Russian characters
  if (/[\u0400-\u04FF]/.test(text)) {
    return 'ru';
  }

  // Hindi characters
  if (/[\u0900-\u097F]/.test(text)) {
    return 'hi';
  }

  // Default to English for Latin characters or unknown scripts
  return 'en';
}