import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Check } from 'lucide-react';
import { Header } from '../components/Header';
import type { Plan } from '../types';

const plans: Plan[] = [
  {
    id: 'free',
    name: 'Free Plan',
    price: 0,
    features: [
      'Basic conversation',
      'Text-to-speech support',
      'Multiple language support',
      'File upload up to 5MB'
    ],
    isFree: true
  },
  {
    id: 'advanced',
    name: 'Advanced ARI',
    price: 2,
    originalPrice: 12,
    features: [
      'Everything in Free Plan',
      'Advanced conversation',
      'Unlimited file uploads',
      'Priority support',
      'Custom voice settings'
    ],
    isFree: false,
    paymentLink: 'https://www.paypal.com/ncp/payment/9PQR3ZYCM6RT2'
  }
];

export const Plans: React.FC = () => {
  const navigate = useNavigate();

  const handlePlanSelect = (plan: Plan) => {
    if (plan.isFree) {
      navigate('/chat');
    } else {
      window.location.href = plan.paymentLink!;
    }
  };

  return (
    <div className="min-h-screen bg-black">
      <Header />
      
      <div className="container mx-auto px-4 pt-24 pb-12">
        <div className="text-center mb-12">
          <h1 className="text-3xl font-bold text-white mb-4">Choose Your Plan</h1>
          <p className="text-gray-400">Select the plan that best fits your needs</p>
        </div>

        <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
          {plans.map((plan) => (
            <div
              key={plan.id}
              className="relative bg-gray-900 rounded-xl p-6 border border-emerald-500/20 hover:border-emerald-500/50 transition-all"
            >
              {!plan.isFree && (
                <div className="absolute -top-3 -right-3 bg-emerald-500 text-black text-sm font-bold px-3 py-1 rounded-full">
                  Special Offer
                </div>
              )}
              
              <h3 className="text-xl font-bold text-white mb-4">{plan.name}</h3>
              
              <div className="mb-6">
                <span className="text-4xl font-bold text-white">${plan.price}</span>
                <span className="text-gray-400">/month</span>
                {plan.originalPrice && (
                  <span className="ml-2 text-gray-500 line-through">
                    ${plan.originalPrice}
                  </span>
                )}
              </div>

              <ul className="space-y-3 mb-8">
                {plan.features.map((feature, index) => (
                  <li key={index} className="flex items-center gap-2 text-gray-300">
                    <Check className="text-emerald-500" size={16} />
                    {feature}
                  </li>
                ))}
              </ul>

              <button
                onClick={() => handlePlanSelect(plan)}
                className="w-full bg-emerald-500 hover:bg-emerald-600 text-black font-semibold py-3 rounded-lg transition-colors"
              >
                {plan.isFree ? 'Start Free' : 'Upgrade Now'}
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};