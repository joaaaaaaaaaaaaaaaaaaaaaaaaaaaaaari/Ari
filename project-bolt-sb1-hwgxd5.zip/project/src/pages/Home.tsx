import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Logo } from '../components/Logo';
import { ArrowRight } from 'lucide-react';

export const Home: React.FC = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-black flex flex-col items-center justify-center p-4">
      <div className="text-center space-y-8 max-w-2xl mx-auto">
        <div className="flex justify-center mb-8">
          <Logo />
        </div>
        
        <h1 className="text-4xl md:text-6xl font-bold text-white">
          Welcome to <span className="text-emerald-400">ARI</span>
        </h1>
        
        <p className="text-xl text-gray-400">
          Your intelligent companion that understands and speaks your language
        </p>

        <button
          onClick={() => navigate('/plans')}
          className="inline-flex items-center gap-2 bg-emerald-500 hover:bg-emerald-600 text-black font-semibold px-8 py-4 rounded-full transition-all transform hover:scale-105"
        >
          Start Now
          <ArrowRight size={20} />
        </button>
      </div>
    </div>
  );
};