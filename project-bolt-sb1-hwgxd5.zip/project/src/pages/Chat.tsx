import React, { useState, useRef, useEffect } from 'react';
import { Mic, Send, Upload, Volume2 } from 'lucide-react';
import { Header } from '../components/Header';
import { useStore } from '../store/useStore';
import { useAI } from '../hooks/useAI';

export const Chat: React.FC = () => {
  const [input, setInput] = useState('');
  const [isRecording, setIsRecording] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const { messages } = useStore();
  const { processMessage, speakResponse, isProcessing } = useAI();

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim() || isProcessing) return;

    try {
      setInput('');
      const response = await processMessage(input);
      if (response.language) {
        await speakResponse(response.content, response.language);
      }
    } catch (error) {
      console.error('Error sending message:', error);
    }
  };

  const handleSpeak = async (text: string, language?: string) => {
    if (language) {
      try {
        await speakResponse(text, language);
      } catch (error) {
        console.error('Error speaking message:', error);
      }
    }
  };

  return (
    <div className="min-h-screen bg-black">
      <Header />
      
      <div className="container mx-auto px-4 pt-20 pb-24">
        <div className="max-w-4xl mx-auto">
          <div className="space-y-4 mb-4">
            {messages.map((message) => (
              <div
                key={message.id}
                className={`flex ${
                  message.role === 'user' ? 'justify-end' : 'justify-start'
                }`}
              >
                <div
                  className={`max-w-[80%] rounded-lg p-4 ${
                    message.role === 'user'
                      ? 'bg-emerald-500 text-black'
                      : 'bg-gray-800 text-white'
                  }`}
                >
                  <p>{message.content}</p>
                  {message.role === 'assistant' && (
                    <button
                      className="mt-2 text-emerald-400 hover:text-emerald-300 transition-colors"
                      onClick={() => handleSpeak(message.content, message.language)}
                    >
                      <Volume2 size={16} />
                    </button>
                  )}
                </div>
              </div>
            ))}
            <div ref={messagesEndRef} />
          </div>

          <div className="fixed bottom-0 left-0 right-0 bg-black/95 border-t border-emerald-500/20 backdrop-blur-sm">
            <div className="container mx-auto px-4 py-4">
              <div className="max-w-4xl mx-auto flex items-center gap-2">
                <button
                  className={`p-2 rounded-full ${
                    isRecording ? 'bg-red-500' : 'bg-gray-800'
                  } text-white hover:opacity-80 transition-opacity`}
                  onClick={() => setIsRecording(!isRecording)}
                >
                  <Mic size={20} />
                </button>
                
                <button
                  className="p-2 rounded-full bg-gray-800 text-white hover:opacity-80 transition-opacity"
                >
                  <Upload size={20} />
                </button>

                <input
                  type="text"
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && handleSend()}
                  placeholder="Type your message..."
                  className="flex-1 bg-gray-800 text-white rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  disabled={isProcessing}
                />

                <button
                  onClick={handleSend}
                  disabled={!input.trim() || isProcessing}
                  className="p-2 rounded-full bg-emerald-500 text-black hover:bg-emerald-600 transition-colors disabled:opacity-50"
                >
                  <Send size={20} />
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};