import React from 'react';
import { Sparkles } from 'lucide-react';

export const Logo: React.FC = () => {
  return (
    <div className="flex items-center gap-2">
      <div className="relative">
        <div className="w-8 h-8 bg-emerald-500 rounded-full animate-pulse"></div>
        <Sparkles className="absolute -top-1 -right-1 text-emerald-300" size={12} />
      </div>
      <span className="text-2xl font-bold bg-gradient-to-r from-emerald-400 to-emerald-600 text-transparent bg-clip-text">
        ARI
      </span>
    </div>
  );
};