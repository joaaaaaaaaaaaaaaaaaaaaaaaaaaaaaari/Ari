export interface Plan {
  id: string;
  name: string;
  price: number;
  originalPrice?: number;
  features: string[];
  isFree: boolean;
  paymentLink?: string;
}

export interface Message {
  id: string;
  content: string;
  role: 'user' | 'assistant';
  timestamp: number;
  language?: string;
}